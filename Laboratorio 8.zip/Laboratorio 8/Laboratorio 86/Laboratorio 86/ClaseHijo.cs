﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ClaseHijo : ClaseBase
{
    public void masTests()
    {

    }
}
